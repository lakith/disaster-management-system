<?php

// php code to Insert data into mysql database from input text
if(isset($_POST['insert']))
{
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $databaseName = "disaster_managment";
    
    // get values form input text and number

    $id = $_POST['id'];
    $Name = $_POST['Name'];
    $Date = $_POST['Date'];
    $Location = $_POST['Location'];
    $Latitude‎ = $_POST['Latitude‎'];
    $Longitude = $_POST['Longitude'];
    $Details = $_POST['Details'];

    
    // connect to mysql database using mysqli

    $connect = mysqli_connect($hostname, $username, $password, $databaseName);
    
    // mysql query to insert data

    $query = "INSERT INTO `save_disaster`(`id`, `Name`, `Date`, `Location`, `Latitude`, `Longitude`, `Details`) VALUES ('$id','$Name','$Date','$Location','$Latitude','$Longitude','$Details')";
    
    $result = mysqli_query($connect,$query);
    
    // check if mysql query successful

    if($result)
    {
        echo 'Data Inserted';
    }
    
    else{
        echo 'Data Not Inserted';
    }
    
    mysqli_free_result($result);
    mysqli_close($connect);
}

?>