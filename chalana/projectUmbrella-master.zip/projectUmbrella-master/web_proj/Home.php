<!doctype html>

<?php

$host = 'localhost';
$username = 'root';
$password = '';

$connection = mysqli_connect($host,$username,$password,'disaster_management');

if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>


<html lang="en">
  <head>
   
   
    <title></title>
    <!-- Required meta tags -->
    
    <style type="text/css">

	#footer_text
	{
		margin-top: 2%;		
	}
	
	#nav_footer
	{
		border-radius: 0px;	
		margin-bottom: -2%;
	}

	#Latest_news2
	{
		text-decoration:none;
	}
		
	#content_change
	{
		margin-top: 2%;	
	}
	
	#footer_style
	{
		margin-left: 40%;
	}
		
	#map {
        height: 400px;
        width: 100%;
		margin-top: 2%;
     }
	
</style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="Icon/font-awesome-4.7.0/css/font-awesome.min.css">
    
  </head>
  <body>

	<nav class="navbar navbar-expand-md  navbar-light" style="background-color: #e3f2fd;">
  <a class="navbar-brand" href="#">Suit name</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">About Us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Our Service</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Contact Us</a>
      </li>  
      <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Dropdown link
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
      </div>
    </li>  
    </ul>
  <ul class="navbar-nav ml-auto">
    <li class="nav-item">
      <a class="nav-link"><i class="fa fa-user-circle" aria-hidden="true"></i>  Add New Users</a>
    </li>
    <li class="navbar-item">
      <a class="nav-link"><i class="fa fa-sign-in" aria-hidden="true"></i>  Login</a>
    </li>
  </ul>
  </div>  
</nav>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-2">
			
		</div>
		<div class="col-sm-8">
    <div id="map"></div>
    <script>
		var uri

		
      function initMap() {
        var uluru = {lat: 6.9271, lng: 79.8612};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 8,
          center: uluru
		  
        });
		 
		var marker = new google.maps.Marker({
		  position: uluru,
          map: map
        });
		  
		
	  }

    </script>

    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDCS9l8lm5HmkQkyNCVveL4REBkc5DaYV4&callback=initMap">
    </script>

		</div>
		<div class="col-sm-2">
			
		</div>
	</div>
</div>
  
<div class="container-fluid" id="content_change">
	<div class="row">
		<div class="col-sm-2">
			<!-- add here-->
		</div>
		<div class="col-sm-8">
			<div class="thumbnail">
        <a href="/w3images/nature.jpg" target="_blank"  id="Latest_news2">
          <img src="image/flood-cars.adapt.945.1.jpg" alt="Flood-Colombo" style="width:100%">
          <div class="caption">
           <?php 
				
				$result = mysqli_query($connection,"select count(1) FROM disaster_info");
				$row = mysqli_fetch_array($result);

				$total = $row[0];
			  
			  	if($total > 0)
				{
					
					$sql = "SELECT heading,short_discription FROM disaster_info WHERE id='".$total."'";

					$result = $connection->query($sql);

					$user_query = mysqli_query($connection, $sql);


					$numrows = mysqli_num_rows($user_query);
					if($numrows < 1){
						echo "No posts";
						exit();	
					}

						while ($row = mysqli_fetch_array($user_query, MYSQLI_ASSOC)) {
						$content = $row["short_discription"];
						$heading = $row["heading"];

					}
				}

		   ?>

          
           <h3 class="text-center"> <p class="text-danger"><?php echo $heading ?></p></h3>
            <p ><?php echo $content ?></p>
          </div>
        </a>
      </div>
		</div>
		<div class="col-sm-2">
			<!-- add here-->
		</div>
		
	</div>
</div>
  
<div class="container-fluid" >
	<div class="row">
		<div class="col-sm-2"></div>
		
		<div class="col-sm-8">
		
		<div class="row">
			<div class="col-sm-6">
				<div class="thumbnail">
        			<a href="#" target="_blank">
         		    <img src="image/du-toitskloof-fire12-900x563.jpg" alt="Natural-Disasters" style="width:100%">
          			<div class="caption">
            			<h2 class="text-center">Natural Disasters</h2>
          			</div>
       				 </a>
     			</div>
			</div>
			<div class="col-sm-6">
				<div class="thumbnail">
        			<a href="#" target="_blank">
         		    <img src="image/4c2a6c76840f1cbc3a3d72e74c0becfe_XL.jpg" alt="Nature" style="width:100%">
          			<div class="caption">
            			<h2 class="text-center">Man Made Disasters</h2>
          			</div>
       				 </a>
     			</div>
			</div>
			</div>
		</div>
		
		</div>
		<div class="col-sm-2"></div>
	</div>
	

  
<nav class="navbar navbar-expand-md navbar-light" id="navstyle" style="background-color: #e3f2fd;">
<ul class="navbar-nav" id="footer_style">
   <div class="container">
   <div class="row">
    <li class="text-center">Coppy right @ Suite name</li>
    </div>
    </div>
  </ul>
</nav>

    
    


    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js" integrity="sha384-vFJXuSJphROIrBnz7yo7oB41mKfc8JzQZiCq4NCceLEaO4IHwicKwpJf9c9IpFgh" crossorigin="anonymous"></script>
    
    <script src="js/bootstrap.min.js"></script>
    
    
  </body>
</html>
<?
mysqli_close($connection);
?>