<?
$username="root";
$password="";
$database="disaster_managment";
?>